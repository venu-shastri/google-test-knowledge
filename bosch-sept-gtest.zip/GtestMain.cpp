#include "gtest/gtest.h"
using namespace testing;
int main() {
	InitGoogleTest();

	return  RUN_ALL_TESTS();
}