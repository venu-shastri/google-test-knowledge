#include <string>
#include <iostream>
#include "gtest/gtest.h"
#include "gmock/gmock.h"
#include "gmock/gmock-matchers.h"
using testing::_;
using testing::StrEq;
using namespace std;
class ITempSensor {
public: virtual int getCurrentTemp() = 0;
};
class IOcuSensor {
public: virtual int getCurrentTemp() = 0;
};
class RFDTempSensor:public ITempSensor{
public:
	int getCurrentTemp() { }

};
class OCTSensor:public IOcuSensor{
public:int getCurrentTemp() { }
	};

//interface - abstarction
class ITemperatueRegulator {
public:virtual int  regulateTemp() = 0;
};
//class TemperatueRegulator implements an interface ITemperatueRegulator
// Realization 
//Contarct b/w two objects
class TemperatueRegulator:public ITemperatueRegulator{
private:
	ITempSensor *tempSensor;
	IOcuSensor *ocuuSensor;
public:
	TemperatueRegulator(ITempSensor *tempSensorPtr,IOcuSensor *octSensorPtr):
		tempSensor{ tempSensorPtr }, ocuuSensor{ octSensorPtr }{

	}
	int  regulateTemp() {
		this->tempSensor->getCurrentTemp();
		this->ocuuSensor->getCurrentTemp();
		return 0;
	}
};


class ILogger {
public:
	virtual ~ILogger() {}
	virtual void writeLog(string message) = 0;
};


class TerminalLogger:public ILogger {
public: 
	void writeLog(string message) {
		cout << message << endl;
	}
};

class AutoClimateControl{
private:
	//has-a (dependency)
	ILogger* logRef;
	ITemperatueRegulator *tempRegulator;
public : 
	//Setter Injection 
	void setLogger(ILogger* ptrToLogger) {
		this->logRef = ptrToLogger;
	}
	//Constructor Dependency Injection
	AutoClimateControl(ITemperatueRegulator* ptrToRegulator) : tempRegulator{ ptrToRegulator } {
		//object InVariant Rules
	}
	void on() {
		this->logRef->writeLog("Auto Climate On!");
		this->tempRegulator->regulateTemp();
		
		this->monitor();
	}
	void off() {
		this->logRef->writeLog("Auto Climate Off!");
	}
	void monitor() {

	}

};


/* Test Env */
class TestTempSensor: public ITempSensor { 
public:
	int getCurrentTemp() { return 0; }
};
class TestOctSensor : public IOcuSensor {
public:
	int getCurrentTemp() { return 0; }
};

class TestLogger:public ILogger{
public: 
	int writeLogcallCount = 0;
	string writeLogFirstArgumentValue;
	void writeLog(string message) {
		this->writeLogcallCount += 1;
		writeLogFirstArgumentValue = message;
	}

};

class TestLoggerMock:public ILogger {
public:
	MOCK_METHOD(void,writeLog,(string message) );
	

};
TEST(AuroClimateControlSystemTestSuite, TestOn) {
	
	//::testing::NiceMock<TestLoggerMock> loggerObj;//Naggy mock -> Nice Mock
	::testing::StrictMock<TestLoggerMock> loggerObj;//Naggy mock -> Nice Mock
	TestTempSensor tempSensorObj;
	TestOctSensor  octSendorObj;
	TemperatueRegulator regulatorObj(&tempSensorObj, &octSendorObj);
	AutoClimateControl objUnderTest(&regulatorObj);
	objUnderTest.setLogger(&loggerObj);
	//Set Expectation 
//	EXPECT_CALL(loggerObj, writeLog(StrEq("Auto Climate On!"))).Times(1);
	objUnderTest.on();
	
}




