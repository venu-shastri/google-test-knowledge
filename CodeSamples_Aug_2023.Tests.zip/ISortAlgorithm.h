#pragma once
#include <vector>
using namespace std;
//interface
class ISortAlgrithm {
public:
    virtual ~ISortAlgrithm(){}
	virtual void sort(vector<int>& source) = 0;
};
