#include "BubbleSort.h"
#include "InsertionSort.h"
#include "gtest/gtest.h"


template <class T>
ISortAlgrithm* CreateSortAlgorithmObject();


template <>
ISortAlgrithm* CreateSortAlgorithmObject<BubbleSort>() {
	return new BubbleSort();
}

template <>
ISortAlgrithm* CreateSortAlgorithmObject<InsertionSort>() {
	return new InsertionSort();
}

template <typename T>
class SortAlgorithmFixture :public testing::Test {
protected:
	ISortAlgrithm* objUnderTest;
	SortAlgorithmFixture() :objUnderTest( CreateSortAlgorithmObject<T>() ) {
		

	}
	~SortAlgorithmFixture() {
		delete objUnderTest;
	}
};

using testing::Types;
typedef Types<BubbleSort,InsertionSort> Implementations;
TYPED_TEST_SUITE(SortAlgorithmFixture, Implementations);

TYPED_TEST(SortAlgorithmFixture, SortMethodTest) {
	vector<int> source = { 1,4,5,2 };
	this->objUnderTest->sort(source);
	ASSERT_EQ(source[3], 5);
}



