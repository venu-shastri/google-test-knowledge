#include "gtest/gtest.h"
#include "InsertionSort.h"
class InsertionSortFixture :public testing::Test {
protected:
	InsertionSort objUnderTest;
};

TEST_F(InsertionSortFixture, SortMethodTest) {
	vector<int> source = { 1,4,5,2 };
	objUnderTest.sort(source);
	ASSERT_EQ(source[3], 5);
}