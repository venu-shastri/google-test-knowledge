#pragma once
#include <vector>
#include "ISortAlgorithm.h"
class BinarySearch
{
private:
	//uses/has-a/dependency relationship
	ISortAlgrithm* sortAlgorithm;
public:
	//Constructor Dependnecy Injection
	BinarySearch(ISortAlgrithm* sortAddreess): sortAlgorithm{sortAddreess}{}
	int search(std::vector<int>& arr, int target);
	~BinarySearch() {
		//delete sortAlgorithm;
	}
};

