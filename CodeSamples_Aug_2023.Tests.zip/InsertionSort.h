#pragma once
#include <vector>
#include "ISortAlgorithm.h"
using namespace std;
class InsertionSort:public ISortAlgrithm
{
public:
    void sort(vector<int>& source);
};

