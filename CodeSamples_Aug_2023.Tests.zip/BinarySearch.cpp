#include "BinarySearch.h"
int BinarySearch::search(std::vector<int>& arr, int target) {
    this->sortAlgorithm->sort(arr);
    int left = 0;
    int right = arr.size() - 1;

    while (left <= right) {
        int mid = left + (right - left) / 2;

        // If the target is found at the middle index, return its index
        if (arr[mid] == target) {
            return mid;
        }

        // If the target is greater than the middle element, search the right half
        if (arr[mid] < target) {
            left = mid + 1;
        }
        // If the target is smaller than the middle element, search the left half
        else {
            right = mid - 1;
        }
    }

    // If the target is not in the array, return -1
    return -1;
}