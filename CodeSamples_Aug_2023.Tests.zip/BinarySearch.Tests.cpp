#include "BinarySearch.h"
#include "gtest/gtest.h"
#include "gmock/gmock.h"
#include "gmock/gmock-actions.h"
#include "gmock/gmock-matchers.h"

using ::testing::_;
using ::testing::Return;

class SortStubImplementation :public ISortAlgrithm {
public:
	void sort(vector<int>& source) {

	}
};
class SortMockImplementation :public ISortAlgrithm {
public:
	int sortMethodCallCount = 0;
	vector<int> argument;
	void sort(vector<int>& source) {
		this->sortMethodCallCount += 1;
		this->argument = vector<int>(source);
	}
};

class SortGoogleMockImplementation :public ISortAlgrithm {
public:
	MOCK_METHOD(void, sort, (vector<int>&));
};

class BinarySearchTestSuite:public testing::Test {
protected:
	BinarySearch* codeUnderTest;
	void SetUp() {
		codeUnderTest = new BinarySearch(new SortMockImplementation());
	}
	void TearDown() {
		delete codeUnderTest;
	}

};

TEST_F(BinarySearchTestSuite, AssertElementExistance) {

	vector<int> source = { 2,5,8,1,6 };
	int searchKey = 8;
	int expectedIndexValue = 2;
	int actulIndexValue = codeUnderTest->search(source,searchKey);
	ASSERT_EQ(actulIndexValue, expectedIndexValue);

}

TEST_F(BinarySearchTestSuite, AssertElementNonExistance) {

	vector<int> source = { 2,5,8,1,6 };
	int searchKey = 10;
	int expectedIndexValue = -1;
	int actulIndexValue = codeUnderTest->search(source, searchKey);
	ASSERT_EQ(actulIndexValue, expectedIndexValue);

}

TEST(BinarySearchIntercationTestSuite, AssertSortInteraction) {

	SortMockImplementation* mockObj = new SortMockImplementation();;
	BinarySearch codeUnderTest{mockObj};
	vector<int> source = { 2,35,7,8 };
	codeUnderTest.search(source,7);
	EXPECT_EQ(mockObj->sortMethodCallCount, 1);
	EXPECT_EQ(source.size(), mockObj->argument.size());
}
TEST(BinarySearchIntercationTestSuite, AssertSortInteractionUsingGmock) {

  // SortGoogleMockImplementation* mockObj = new SortGoogleMockImplementation();;
  
	//::testing::NiceMock<SortGoogleMockImplementation> mockObj;
	::testing::StrictMock<SortGoogleMockImplementation> mockObj;
	BinarySearch codeUnderTest{ &mockObj };
	vector<int> source = { 2,35,7,8 };
	EXPECT_CALL(mockObj, sort(source)).Times(1);
	int actualIndex=codeUnderTest.search(source, 7);
	EXPECT_EQ(actualIndex, 2);
	
}