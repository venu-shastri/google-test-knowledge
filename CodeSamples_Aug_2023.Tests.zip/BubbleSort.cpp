#include "BubbleSort.h"

void BubbleSort::sort(vector<int> & source) {

	//implementation
    int n = source.size();
    bool swapped;

    for (int i = 0; i < n - 1; i++) {
        swapped = false;

        for (int j = 0; j < n - i - 1; j++) {
            // If the current element is greater than the next element, swap them
            if (source[j] > source[j + 1]) {
                std::swap(source[j], source[j + 1]);
                swapped = true;
            }
        }

        // If no two elements were swapped in the inner loop, the array is already sorted
        if (!swapped) {
            break;
        }
    }

}
