#include <string>
#include <vector>
#include <numeric>
#include <regex>

using namespace std;

class StringCalculator {
public:
	int Add(const string& input);
};
