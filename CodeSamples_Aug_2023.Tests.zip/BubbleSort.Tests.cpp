#include "gtest/gtest.h"
#include "BubbleSort.h"
class BubbleSortFixture :public testing::Test {
protected:
	BubbleSort objUnderTest;
};

TEST_F(BubbleSortFixture, SortMethodTest) {
	vector<int> source = { 1,4,5,2 };
	objUnderTest.sort(source);
	ASSERT_EQ(source[3], 5);
}