#include "StringCalculator.h"
#include "gtest/gtest.h"

//Fixture Class
class StringCalculatorAddTestSuite :public testing::Test{
protected:
	//Reusable Code
	StringCalculator* objUnderTest;
	//Before TEST_F() execution
	//StringCalculatorAddTestSuite() {
	void SetUp(){
		objUnderTest = new StringCalculator();//malloc
	}
	//After TEST_F() execuction
	//~StringCalculatorAddTestSuite() {
	void TearDown(){
		delete objUnderTest; //free
	}
};

TEST_F(StringCalculatorAddTestSuite,Returns0ForEmptyStringInput) {
	//Arrange
	string input = "";
	int expectedValue = 0;
	//Act
	int actualValue=objUnderTest->Add(input);
	//Assert
	ASSERT_EQ(actualValue, expectedValue);

}
TEST_F(StringCalculatorAddTestSuite, WhenSingleNumberPassedShouldReturnSameNumber) {
	//Arrange
	string input = "9";
	int expectedValue = 9;
	//Act
	int actualValue = objUnderTest->Add(input);
	//Assert
	ASSERT_EQ(actualValue, expectedValue);

}
TEST_F(StringCalculatorAddTestSuite, Returns0ForArgument0) {
	//Arrange
	
	string input = "9";
	int expectedValue = 9;
	//Act
	int actualValue = objUnderTest->Add(input);
	//Assert
	ASSERT_EQ(actualValue, expectedValue);

}
TEST_F(StringCalculatorAddTestSuite, RetunrsSumOfallWhenPassedSingleCommaDelimitedNumbers) {
	//Arrange
	string input = "3,2";
	int expectedValue = 5;
	//Act
	int actualValue = objUnderTest->Add(input);
	//Assert
	ASSERT_EQ(actualValue, expectedValue);

}
TEST_F(StringCalculatorAddTestSuite, RetunrsSumOfallWhenPassedTwoCommaDelimitedNumbers) {
	//Arrange
	
	string input = "3,2,6";
	int expectedValue = 11;
	//Act
	int actualValue = objUnderTest->Add(input);
	//Assert
	ASSERT_EQ(actualValue, expectedValue);

}
TEST_F(StringCalculatorAddTestSuite, thorowsInvalidArgumentExceptionForNegetiveNumbers) {
	//Arrange

	string input = "3,-2,6";
	//Expecting "std::invalid_argument" exception
	EXPECT_THROW(objUnderTest->Add(input), std::invalid_argument);
}


class StringCalculatorAddParameterizedTestSuite:public testing::TestWithParam<std::tuple<string,int>> {
protected:
	StringCalculator objUnderTest;
};

TEST_P(StringCalculatorAddParameterizedTestSuite, ParmeterizedTestCase) {
	//Arrange
	string input = std::get<0>(GetParam());
	int expectedValue = std::get<1>(GetParam());
	//Act
	int actualValue = objUnderTest.Add(input);
	//Assert
	ASSERT_EQ(actualValue, expectedValue);

}

INSTANTIATE_TEST_SUITE_P(
	AddMethodParameterizedTest,
	StringCalculatorAddParameterizedTestSuite,
	::testing::Values(
		std::make_tuple("",0),
		std::make_tuple("0", 0),
		std::make_tuple("9", 9),
		std::make_tuple("3,2", 5)
	));